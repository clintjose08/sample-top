import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import Toggle from 'material-ui/Toggle';
import logo from './logo.svg';
import {RadioButton, RadioButtonGroup} from 'material-ui/RadioButton';
import TextField from 'material-ui/TextField';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import {Card} from 'material-ui/Card';
import {
  Table,
  TableBody,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';
import './App.css';
const styles = {
  block: {
    maxWidth: 250,
  },
  toggle: {
    marginBottom: 16,
  },
  thumbOff: {
    backgroundColor: '#ffcccc',
  },
  trackOff: {
    backgroundColor: '#ff9d9d',
  },
  thumbSwitched: {
    backgroundColor: 'red',
  },
  trackSwitched: {
    backgroundColor: '#ff9d9d',
  },
  labelStyle: {
    color: 'red',
  },
};
class App extends Component {

  render() {
    return (
      <MuiThemeProvider>
        <div className="layout">
         <Card style={{padding:20,boxShadow: "5px 5px 13px grey"}}>
          <RadioButtonGroup style={{display:"flex"}}>
          <RadioButton
              style={{marginRight:50}}
              value="Existing Customer"
              label="Existing Customer"
            />
            <RadioButton
                style={{marginRight:50}}
                value="New Customer"
                label="New Customer"
              />
           </RadioButtonGroup>
           </Card>
           <br/>
           <Card style={{padding:20,boxShadow: "5px 5px 13px grey"}}>
           <div>
           Age
           <TextField style={{float:"Right",width:"10%",height:30}}
            defaultValue="10"
            type="number"
           />
           </div>
           <br/>
           <div style={{display:"flex",width:"100%"}}>
           <p style={{paddingTop:15, width:"80%"}}>Gender</p>
           <SelectField value={1} style={{float:"Right",width:"20%"}}>
              <MenuItem value={1} primaryText="Male" />
              <MenuItem value={2} primaryText="Female" />
              <MenuItem value={3} primaryText="Other" />
            </SelectField>
            </div>
             <br/>
            <Toggle
              label="Is Married"
              defaultToggled={true}
              style={styles.toggle}
            />
             <br/>
            <Toggle
              label="Is Joint Loan"
              defaultToggled={true}
              style={styles.toggle}
            />
             <br/>
            <Toggle
              label="Is Joint applicant earning"
              defaultToggled={true}
              style={styles.toggle}
            />
            <br/>
            <div>
            Number of Dependants
            <TextField style={{float:"Right",width:"10%", height:30}}
             defaultValue="0"
             type="number"
            />
            </div>
            <br/>
            <Toggle
              label="Criminal record"
              defaultToggled={true}
              style={styles.toggle}
            />
            <br/>
            <Toggle
              label="Has user defaulted any time before"
              defaultToggled={true}
              style={styles.toggle}
            />
            <br/>
            <div>
            Number of years of relationship with bank
            <TextField  style={{float:"Right",width:"10%", height:30}}
            defaultValue="0"
             type="number"
            />
            </div>
            <br/>
            <div>
            Credit Score
            <TextField style={{float:"Right",width:"10%", height:30}}
             defaultValue="345"
             type="number"
            />
            </div>
            <br/>
            <div>
            Annual Income
            <TextField style={{float:"Right",width:"10%", height:30}}
             defaultValue="500000"
             type="number"
            />
            </div>
            </Card>
            </div>
      </MuiThemeProvider>
    );
  }
}

export default App;
